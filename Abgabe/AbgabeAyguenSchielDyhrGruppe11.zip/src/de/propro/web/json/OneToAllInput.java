package de.propro.web.json;

public class OneToAllInput {
	public double lat;
	public double lng;
}
