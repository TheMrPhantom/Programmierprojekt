package de.propro.web.json.geojson;

public class Style {
	public String color;
	public int weight;
	public double opacity;
	
	public Style(String color, int weight, double opacity) {
		this.color = color;
		this.weight = weight;
		this.opacity = opacity;
	}
	
	
}
