package de.propro.web.json;

public class MultipleQueueInput {
	public int[] startNodes;
	public int[] endNodes;
}
