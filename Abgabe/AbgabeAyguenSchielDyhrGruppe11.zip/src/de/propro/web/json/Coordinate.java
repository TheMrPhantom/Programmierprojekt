package de.propro.web.json;

public class Coordinate {
	public double lat;
	public double lng;
}
