package de.propro.backend.dijkstra;

import java.util.ArrayList;

public class DijkstraOneToAllResult {
	public int[] nodeCosts;
	public double time;
}
