package de.propro.web.json.geojson;

public class Property {
	public String color="green";
}
