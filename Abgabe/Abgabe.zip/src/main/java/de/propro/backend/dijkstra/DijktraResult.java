package de.propro.backend.dijkstra;

import java.util.ArrayList;

public class DijktraResult {
	public ArrayList<Integer> path;
	public int length;
}
